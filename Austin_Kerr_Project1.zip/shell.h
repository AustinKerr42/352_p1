#ifndef SHELL_H
# define SHELL_H

#define MAXLINE 80 /* The maximum length command */

void execvp(char *command, char *params[]);
changeDirectory(char *command, char *params[])

#endif
